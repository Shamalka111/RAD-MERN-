module.exports ={
    db: 'mongodb+srv://admin:admin@cluster2.yly5y67.mongodb.net/?retryWrites=true&w=majority'
}