import './App.css';
import Menu from './Menu';
import {BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';
import AddTeacher from './components/AddTeacher';
import ViewTeacher from './components/ViewTeacher';
import EditTeacher from './components/EditTeacher';


function App() {
  return (
    <>
    <Router>
    <Menu/>
    <Routes>
      <Route path="/" element={<ViewTeacher/>} />
      <Route path="/add-teacher" element={<AddTeacher/>} />
      <Route path="/edit-teacher/:id" element={<EditTeacher/>} />
    
    </Routes>

    </Router>

    </>
  );
}

export default App;
